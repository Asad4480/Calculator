#! /usr/bin/env node 
// This is called shebang command line, b/c scrift should be run in NodeJS

import inquirer from "inquirer";
import chalk from "chalk";
import chalkAnimation from "chalk-animation";
import Choices from "inquirer/lib/objects/choices.js";
import { start } from "repl";


const silentDisplay = () => {
 return new Promise((res)=> {
        setTimeout(res,2000);
    })
}

async function display (){
    let rainbowTitle = chalkAnimation.rainbow('Lets Start Calculation'); // start animation
    await silentDisplay();
    rainbowTitle.stop();
}
await display()
async function question (){const answer = await inquirer.prompt([{
    type: "list",
    name: "operatore",
    message: "Which Operation You Want to Perform ? \n",
    choices: ["Addition", "Subtraction", "Multiplication", "Division"]
},
{ type: "number",
name: "num1",
message: "Enter Number 1:"},
{type: "number",
name: "num2",
message: "Enter Number 2:"},
]);
    if(answer.operatore == "Addition"){
    console.log(chalk.green(`${answer.num1} + ${answer.num2} = ${answer.num1 + answer.num2}`));
}
     else if(answer.operatore == "Subtraction"){
        console.log(chalk.green(`${answer.num1} - ${answer.num2} = ${answer.num1 - answer.num2}`))}
     else if(answer.operatore == "Multiplication"){
        console.log(chalk.green(`${answer.num1} * ${answer.num2} = ${answer.num1 * answer.num2}`))}
     else if(answer.operatore == "Division"){
        console.log(chalk.green(`${answer.num1} / ${answer.num2} = ${answer.num1 / answer.num2}`))}
};
async function askAgain(){
    do{
       await question();
        var again = await inquirer.prompt({
        type: "input",
         name: "restart",
         message: "Do You Want to Continue ? Press y or n:"

    })}

while (again.restart == "y" || again.restart == "Y" || again.restart == "yes"|| again.restart == "YES")    

    }
askAgain();




















